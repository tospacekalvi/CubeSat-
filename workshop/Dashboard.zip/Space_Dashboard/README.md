# LUNA 1U Mission Control – Refined Edition

## What is fixed
- Fixed the 3D initialisation order: the previous page attempted to use `THREE` before its deferred ES module had loaded. This caused the 3D script to stop before rendering the spacecraft.
- The LUNA 1U model now initialises from a regular browser script and displays a clear message if the 3D library CDN cannot be reached.
- Serial parser supports the existing MicroPython output labels and dictionary format without changing Pico firmware.
- Telemetry sample history now records exactly one sample for each valid `Accelerometer: {...}` packet, rather than depending on unrelated lines arriving after it.
- Added serial line and valid accelerometer packet counters to help distinguish a connected COM port from actual incoming telemetry.
- Kept live attitude/environment graphs, CSV export, mission event log, raw serial monitor and smooth continuous 3D rendering.

## Windows setup
1. Extract the ZIP.
2. Open Command Prompt in the extracted `luna_mission_control_pro` folder.
3. Install dependencies: `py -m pip install -r requirements.txt`
4. Close Thonny Shell and any other serial monitor using the Pico COM port.
5. Run: `py app.py`
6. Open: `http://127.0.0.1:5000`
7. Select the Pico COM port (for example COM30), select 115200 baud and click Connect Spacecraft.

## Expected Pico serial format
The existing Pico code can remain unchanged. The dashboard recognises lines such as:

```text
Temperature: 28.41 °C
Pressure: 1013.369 hPa
Air Status: Air is Clean
Accelerometer: {'z': 0.9694824, 'y': 0.387207, 'x': -0.05664063}
Gyroscope (°/s): {'z': 1.580153, 'y': 1.885496, 'x': -1.038168}
Gyroscope Raw X: -148
Gyroscope Raw Y: 242
Gyroscope Raw Z: 204
Tilt Direction: Stable
Rotation: No major rotation
```

## If the dashboard says Connected but shows 0 samples
- Look at the RAW SERIAL TELEMETRY panel near the bottom of the page.
- If it says `Waiting for Pico serial data…` and no lines arrive, check that the Pico program is running, the selected COM port is correct, and Thonny/other serial terminals are closed.
- If raw lines arrive but sample count stays at zero, verify that the accelerometer line begins with `Accelerometer:` and contains a Python dictionary with x, y and z keys.
- The 3D model and Chart.js graphs load from public CDNs; keep the browser connected to the internet while opening the dashboard.

## Important engineering note
Accelerometer gravity-vector calculations provide roll and pitch estimates when the board is relatively still. They do not provide absolute yaw. The gyroscope is displayed independently; sensor-fusion filtering can be added later if required.
