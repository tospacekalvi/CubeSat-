from flask import Flask, render_template, request, jsonify, Response
import serial
import serial.tools.list_ports
import threading
import time
import re
import ast
import math
import csv
import io
from collections import deque
from datetime import datetime

app = Flask(__name__)
serial_conn = None
serial_lock = threading.RLock()
state_lock = threading.RLock()
stop_reader = threading.Event()
reader_thread = None

state = {
    "connected": False, "port": None, "baudrate": 115200,
    "temperature": None, "pressure": None, "air_status": "Waiting for data",
    "tilt": "Waiting for data", "rotation": "Waiting for data",
    "accelerometer": {"x": None, "y": None, "z": None},
    "gyroscope": {"x": None, "y": None, "z": None},
    "gyro_raw": {"x": None, "y": None, "z": None},
    "last_update": None, "last_update_epoch": None, "error": None,
    "line_count": 0, "accel_count": 0,
    "logs": deque(maxlen=180), "events": deque(maxlen=100),
    "history": deque(maxlen=2400), "started_at": time.time()
}


def add_event(kind, message):
    with state_lock:
        state["events"].append({"time": time.strftime("%H:%M:%S"), "kind": kind, "message": message})


def add_log(line):
    with state_lock:
        state["logs"].append({"time": time.strftime("%H:%M:%S"), "text": line})


def parse_xyz_dict(payload):
    """Parse MicroPython dict strings such as {'z': 0.97, 'y': 0.38, 'x': -0.05}."""
    try:
        obj = ast.literal_eval(payload.strip())
        if isinstance(obj, dict):
            result = {}
            for axis in ("x", "y", "z"):
                if axis in obj:
                    value = float(obj[axis])
                    if math.isfinite(value):
                        result[axis] = value
            return result if result else None
    except (ValueError, SyntaxError, TypeError, OverflowError):
        return None
    return None


def numeric_value(text):
    match = re.search(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", text)
    if not match:
        return None
    try:
        value = float(match.group(0))
        return value if math.isfinite(value) else None
    except ValueError:
        return None


def record_sample_locked():
    a, g = state["accelerometer"], state["gyroscope"]
    if not all(a[k] is not None for k in ("x", "y", "z")):
        return
    x, y, z = a["x"], a["y"], a["z"]
    roll = math.degrees(math.atan2(y, z))
    pitch = math.degrees(math.atan2(-x, math.sqrt(y * y + z * z)))
    now = time.time()
    state["history"].append({
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "epoch": now, "temperature": state["temperature"], "pressure": state["pressure"],
        "air_status": state["air_status"], "ax": x, "ay": y, "az": z,
        "gx": g["x"], "gy": g["y"], "gz": g["z"], "roll": roll, "pitch": pitch
    })


def parse_serial_line(line):
    clean = line.strip().lstrip("\ufeff")
    if not clean:
        return
    lower = clean.lower()
    event = None
    with state_lock:
        state["line_count"] += 1
        state["last_update"] = time.strftime("%H:%M:%S")
        state["last_update_epoch"] = time.time()

        # Keep the user's current MicroPython labels and dictionary format unchanged.
        if "accelerometer" in lower and ":" in clean:
            values = parse_xyz_dict(clean.split(":", 1)[1])
            if values and all(k in values for k in ("x", "y", "z")):
                state["accelerometer"].update(values)
                state["accel_count"] += 1
                record_sample_locked()  # One sample per valid accelerometer packet.
        elif "gyroscope raw x" in lower:
            value = numeric_value(clean.split(":", 1)[-1])
            if value is not None: state["gyro_raw"]["x"] = int(value)
        elif "gyroscope raw y" in lower:
            value = numeric_value(clean.split(":", 1)[-1])
            if value is not None: state["gyro_raw"]["y"] = int(value)
        elif "gyroscope raw z" in lower:
            value = numeric_value(clean.split(":", 1)[-1])
            if value is not None: state["gyro_raw"]["z"] = int(value)
        elif "gyroscope" in lower and ":" in clean:
            values = parse_xyz_dict(clean.split(":", 1)[1])
            if values: state["gyroscope"].update(values)
        elif "temperature" in lower:
            value = numeric_value(clean)
            if value is not None: state["temperature"] = value
        elif "pressure" in lower:
            value = numeric_value(clean)
            if value is not None: state["pressure"] = value
        elif "air status" in lower:
            state["air_status"] = clean.split(":", 1)[-1].strip()
            event = ("good", f"Air status updated: {state['air_status']}")
        elif "tilt direction" in lower:
            state["tilt"] = clean.split(":", 1)[-1].strip()
        elif lower.startswith("rotation"):
            state["rotation"] = clean.split(":", 1)[-1].strip()
            if "no major" not in state["rotation"].lower():
                event = ("warning", f"Rotation detected: {state['rotation']}")
    if event:
        add_event(*event)


def serial_reader(conn):
    """Own the serial object in one worker; decode complete Pico lines safely."""
    try:
        while not stop_reader.is_set():
            if not conn.is_open:
                break
            raw = conn.readline()
            if not raw:
                continue
            line = raw.decode("utf-8", errors="replace").strip()
            if line:
                add_log(line)
                parse_serial_line(line)
    except Exception as exc:
        if not stop_reader.is_set():
            with state_lock:
                state["error"] = str(exc)
            add_log(f"Serial read error: {exc}")
            add_event("danger", f"Serial read error: {exc}")
    finally:
        try:
            if conn and conn.is_open:
                conn.close()
        except Exception:
            pass
        with serial_lock:
            global serial_conn
            if serial_conn is conn:
                serial_conn = None
        with state_lock:
            was_connected = state["connected"]
            state["connected"] = False
            state["port"] = None
        if was_connected and not stop_reader.is_set():
            add_event("warning", "USB serial connection closed")


@app.route("/")
def index():
    return render_template("index.html")


@app.get("/api/ports")
def get_ports():
    return jsonify({"ports": [{"device": p.device, "description": p.description}
                              for p in serial.tools.list_ports.comports()]})


@app.post("/api/connect")
def connect():
    global serial_conn, reader_thread
    payload = request.get_json(silent=True) or {}
    port = (payload.get("port") or "").strip()
    if not port:
        return jsonify({"ok": False, "error": "Enter a COM port, for example COM30."}), 400
    try:
        baudrate = int(payload.get("baudrate", 115200))
        if baudrate != 115200:
            return jsonify({"ok": False, "error": "Use 115200 baud for this Pico project."}), 400
        stop_reader.set()
        with serial_lock:
            old = serial_conn
            serial_conn = None
        if old:
            try: old.close()
            except Exception: pass
        if reader_thread and reader_thread.is_alive():
            reader_thread.join(timeout=0.5)
        conn = serial.Serial(port=port, baudrate=baudrate, timeout=0.20,
                             write_timeout=0.20, exclusive=None)
        try: conn.reset_input_buffer()
        except Exception: pass
        stop_reader.clear()
        with state_lock:
            state.update({
                "connected": True, "port": port, "baudrate": baudrate,
                "temperature": None, "pressure": None,
                "air_status": "Waiting for data", "tilt": "Waiting for data",
                "rotation": "Waiting for data", "last_update": None,
                "last_update_epoch": None, "error": None,
                "line_count": 0, "accel_count": 0,
                "accelerometer": {"x": None, "y": None, "z": None},
                "gyroscope": {"x": None, "y": None, "z": None},
                "gyro_raw": {"x": None, "y": None, "z": None}
            })
            state["logs"].clear()
            state["history"].clear()
        add_event("good", f"Connected to {port} at {baudrate} baud")
        serial_conn = conn
        reader_thread = threading.Thread(target=serial_reader, args=(conn,), daemon=True)
        reader_thread.start()
        return jsonify({"ok": True, "message": f"Connected to {port} at {baudrate} baud."})
    except Exception as exc:
        with state_lock:
            state["connected"] = False
            state["port"] = None
            state["error"] = str(exc)
        add_event("danger", f"Connection failed: {exc}")
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.post("/api/disconnect")
def disconnect():
    stop_reader.set()
    with serial_lock:
        conn = serial_conn
    if conn:
        try: conn.close()
        except Exception: pass
    with state_lock:
        state["connected"] = False
        state["port"] = None
    add_event("warning", "Pico disconnected by operator")
    return jsonify({"ok": True})


@app.get("/api/status")
def get_status():
    with state_lock:
        return jsonify({
            "connected": state["connected"], "port": state["port"], "baudrate": state["baudrate"],
            "temperature": state["temperature"], "pressure": state["pressure"],
            "air_status": state["air_status"], "tilt": state["tilt"], "rotation": state["rotation"],
            "accelerometer": dict(state["accelerometer"]), "gyroscope": dict(state["gyroscope"]),
            "gyro_raw": dict(state["gyro_raw"]), "last_update": state["last_update"],
            "last_update_epoch": state["last_update_epoch"], "error": state["error"],
            "line_count": state["line_count"], "accel_count": state["accel_count"],
            "logs": list(state["logs"])[-55:], "events": list(state["events"])[-35:],
            "uptime": int(time.time() - state["started_at"]),
            "sample_count": len(state["history"])
        })


@app.get("/api/history")
def get_history():
    with state_lock:
        return jsonify({"history": list(state["history"])[-240:]})


@app.get("/api/export.csv")
def export_csv():
    with state_lock:
        rows = list(state["history"])
    output = io.StringIO()
    fields = ["timestamp", "temperature", "pressure", "air_status", "ax", "ay", "az", "gx", "gy", "gz", "roll", "pitch"]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    filename = "LUNA_telemetry_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".csv"
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={filename}"})


if __name__ == "__main__":
    print("LUNA Mission Control: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
