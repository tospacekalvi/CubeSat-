@echo off
setlocal enabledelayedexpansion

set "counter=0"

:loop
cls
echo Flashed Devices Count: !counter!
echo Checking for E: drive...

rem Wait until E: is connected
:waitConnect
if exist E:\ (
    echo Device is connected.
) else (
    echo Device not connected. Retrying in 2 seconds...
    timeout /t 2 /nobreak >nul
    goto waitConnect
)

rem Copy the UF2 file
echo Copying UF2 file to E:\
copy /Y "RPI_PICO-20250415-v1.25.0.uf2" "E:\" >nul
if %errorlevel%==0 (
    set /a counter+=1
    echo Copy successful. Total flasheE: !counter!
) else (
    echo Copy failed. Trying again...
)

rem Wait for the Pico to reboot
echo Waiting 3 seconds for device reboot...
timeout /t 3 /nobreak >nul

rem Wait until E: is disconnected
:waitDisconnect
if exist E:\ (
    echo Waiting for device to disconnect...
    timeout /t 1 /nobreak >nul
    goto waitDisconnect
)

echo Device disconnected. Ready for next connection.
goto loop
